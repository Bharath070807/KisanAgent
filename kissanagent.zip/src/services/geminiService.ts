import { GoogleGenAI } from "@google/genai";
import { Language } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function getAgriExpertAdvice(query: string, lang: Language, imageData?: { data: string, mimeType: string }) {
  const langNames = {
    en: "English",
    hi: "Hindi",
    te: "Telugu",
    pa: "Punjabi",
    mr: "Marathi",
    kn: "Kannada"
  };

  const systemPrompt = `## YOUR IDENTITY
- Name: KissanAgent
- Tagline: "Your Smart Farming Companion"
- Language: Respond in the SAME language the farmer uses (Detected Language: ${langNames[lang] || 'Indian English'}). Use very simple words, like a helpful local farmer guide. Avoid scientific jargon.

## RESPONSE FORMAT (MANDATORY for Crop/Disease queries):
🌱 Problem: (Simple name)
🔍 Pehchaan: (2-3 simple points seen with eyes)
💊 Ilaaj: 
   - Organic: (Home/Natural remedy)
   - Chemical: (Simple name)
⚠️ Dhyaan: (Precautions)
🌾 Result: (What to expect)

## RULES
- Be voice-friendly (short sentences, no complex symbols).
- No complex terms. Replace scientific names with common names.
- Act like an experienced local farmer friend, not a scientist.
- End with: "Koi aur sawaal? / Any other question?"`;

  const contents: any[] = [];
  
  if (imageData) {
    contents.push({
      inlineData: {
        data: imageData.data,
        mimeType: imageData.mimeType
      }
    });
  }
  
  contents.push({ text: `User query: ${query || "What is in this image?"}\n\nSystem: ${systemPrompt}` });

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: { parts: contents },
    });
    return response.text || "I'm sorry, I couldn't process that. Please try again.";
  } catch (error) {
    console.error("Gemini API error:", error);
    return "Something went wrong. Please check your internet connection.";
  }
}
