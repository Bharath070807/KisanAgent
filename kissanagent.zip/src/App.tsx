/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sprout, TrendingUp, Landmark, Mic, Cloud } from 'lucide-react';
import { Header } from './components/Header';
import { FeatureCard } from './components/FeatureCard';
import { AIFeldExpert } from './components/AIFeldExpert';
import { MandiBoard } from './components/MandiBoard';
import { SchemePortal } from './components/SchemePortal';
import { Language, translations } from './types';
import { useVoiceRecognition } from './hooks/useVoice';

type View = 'dashboard' | 'ai' | 'mandi' | 'schemes';

export default function App() {
  const [lang, setLang] = useState<Language>('hi');
  const [view, setView] = useState<View>('dashboard');
  const t = translations[lang];
  const { isListening, startListening, transcript } = useVoiceRecognition();

  // Voice navigation logic
  if (transcript && isListening === false) {
    const text = transcript.toLowerCase();
    if (text.includes('मंडी') || text.includes('mandi') || text.includes('भाव')) setView('mandi');
    if (text.includes('एआई') || text.includes('ai') || text.includes('सहायक') || text.includes('एजेंट')) setView('ai');
    if (text.includes('योजना') || text.includes('scheme') || text.includes('सरकारी')) setView('schemes');
    if (text.includes('वापस') || text.includes('back') || text.includes('होम')) setView('dashboard');
  }

  return (
    <div className="min-h-screen flex flex-col font-sans">
      <Header lang={lang} setLang={setLang} />

      <main className="flex-1 overflow-x-hidden">
        <AnimatePresence mode="wait">
          {view === 'dashboard' && (
            <motion.div
              key="dashboard"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-8 pb-20"
            >
              {/* Hero Section */}
              <section className="relative h-[450px] flex items-center justify-center overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1592982537447-7440770cbfc9?q=80&w=2000" 
                  alt="Farmer Hero" 
                  className="absolute inset-0 w-full h-full object-cover brightness-[0.4]"
                  referrerPolicy="no-referrer"
                />
                <div className="relative z-10 text-center px-6 max-w-4xl mx-auto space-y-6">
                  <motion.div
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.2 }}
                  >
                    <h2 className="text-5xl md:text-7xl font-bold text-white serif leading-tight">
                      {t.title}
                    </h2>
                    <p className="text-xl md:text-2xl text-earth-200 mt-4 font-medium opacity-90">
                      {t.tagline}
                    </p>
                  </motion.div>

                  <motion.div 
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 0.4 }}
                    className="flex flex-wrap justify-center gap-4 mt-8"
                  >
                    <div className="bg-white/10 backdrop-blur-md px-6 py-3 rounded-2xl flex items-center gap-3 border border-white/20 text-white">
                      <Cloud size={24} className="text-sky-300" />
                      <span className="font-bold">28°C · Sunny</span>
                    </div>
                    <div className="bg-white/10 backdrop-blur-md px-6 py-3 rounded-2xl flex items-center gap-3 border border-white/20 text-white">
                      <TrendingUp size={24} className="text-green-400" />
                      <span className="font-bold">Wheat: ₹2,350 ↑</span>
                    </div>
                  </motion.div>
                </div>
              </section>

              {/* Quick Actions Grid */}
              <section className="max-w-6xl mx-auto px-6 -mt-24 relative z-20">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  <FeatureCard 
                    title={t.aiExpert}
                    icon={Sprout}
                    onClick={() => setView('ai')}
                    colorClass="border-b-leaf-600"
                  />
                  <FeatureCard 
                    title={t.mandiPrices}
                    icon={TrendingUp}
                    onClick={() => setView('mandi')}
                    colorClass="border-b-earth-500"
                  />
                  <FeatureCard 
                    title={t.schemes}
                    icon={Landmark}
                    onClick={() => setView('schemes')}
                    colorClass="border-b-blue-600"
                  />
                </div>
              </section>

              {/* Information Row */}
              <section className="max-w-6xl mx-auto px-6 py-12">
                <div className="bg-leaf-800 rounded-[3rem] p-10 text-white flex flex-col md:flex-row items-center gap-12 shadow-2xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-64 h-64 bg-leaf-700/50 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl" />
                  
                  <div className="flex-1 space-y-4 relative z-10">
                    <h3 className="text-3xl font-bold serif leading-snug">
                      {lang === 'hi' ? 'क्या आपकी फसल बीमार है?' : 'Is your crop sick?'}
                    </h3>
                    <p className="text-lg text-leaf-100 opacity-90">
                      {lang === 'hi' 
                        ? 'हमारे एआई विशेषज्ञ से बात करें और अपनी फसल के लिए तुरंत उपाय पाएं।' 
                        : 'Talk to our AI expert and get instant remedies for your crops.'}
                    </p>
                    <button 
                      onClick={() => setView('ai')}
                      className="mt-4 px-8 py-4 bg-earth-400 text-earth-950 font-bold rounded-2xl hover:bg-earth-300 transition-colors shadow-lg"
                    >
                      {lang === 'hi' ? 'अभी बात करें' : 'Talk Now'}
                    </button>
                  </div>

                  <div className="relative">
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={() => startListening(lang)}
                      className={`w-32 h-32 rounded-full flex flex-col items-center justify-center gap-2 shadow-2xl transition-all ${
                        isListening ? 'bg-red-500 animate-pulse' : 'bg-white text-leaf-800'
                      }`}
                    >
                      <Mic size={40} />
                      <span className="text-xs font-bold uppercase tracking-widest">
                        {isListening ? 'Listening' : 'Voice'}
                      </span>
                    </motion.button>
                  </div>
                </div>
              </section>
            </motion.div>
          )}

          {view === 'ai' && <AIFeldExpert key="ai-view" lang={lang} onBack={() => setView('dashboard')} />}
          {view === 'mandi' && <MandiBoard key="mandi-view" lang={lang} onBack={() => setView('dashboard')} />}
          {view === 'schemes' && <SchemePortal key="schemes-view" lang={lang} onBack={() => setView('dashboard')} />}
        </AnimatePresence>
      </main>

      {/* Footer Nav for Mobile (Optional but good for UX) */}
      {view === 'dashboard' && (
        <div className="fixed bottom-8 left-1/2 -translate-x-1/2 md:hidden z-50">
          <button 
            onClick={() => startListening(lang)}
            className={`p-6 rounded-full shadow-2xl flex items-center justify-center ${
              isListening ? 'bg-red-500 text-white' : 'bg-leaf-600 text-white'
            }`}
          >
            <Mic size={32} />
          </button>
        </div>
      )}
    </div>
  );
}

