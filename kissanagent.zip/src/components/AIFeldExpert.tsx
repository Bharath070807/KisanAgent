import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mic, Send, Bot, User, Trash2, Volume2, VolumeX, ArrowLeft, Camera, Image as ImageIcon, X } from 'lucide-react';
import { getAgriExpertAdvice } from '../services/geminiService';
import { Language, translations } from '../types';
import { useVoiceRecognition } from '../hooks/useVoice';

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  image?: string;
}

export const AIFeldExpert: React.FC<{ lang: Language; onBack: () => void }> = ({ lang, onBack }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [autoSpeak, setAutoSpeak] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const t = translations[lang];
  const { isListening, isSpeaking, transcript, startListening, speak, stopSpeaking } = useVoiceRecognition();

  useEffect(() => {
    if (transcript && isListening === false) {
      handleSend(transcript);
    }
  }, [transcript, isListening]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const clearImage = () => {
    setSelectedImage(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSend = async (text: string) => {
    const messageContent = text.trim();
    if (!messageContent && !selectedImage) return;

    const userMessage: ChatMessage = { 
      role: 'user', 
      content: messageContent,
      image: selectedImage || undefined
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    const imageData = selectedImage ? {
      data: selectedImage.split(',')[1],
      mimeType: selectedImage.split(';')[0].split(':')[1]
    } : undefined;

    setSelectedImage(null);
    if (fileInputRef.current) fileInputRef.current.value = '';

    const response = await getAgriExpertAdvice(messageContent, lang, imageData);
    const aiMessage: ChatMessage = { role: 'assistant', content: response };
    setMessages(prev => [...prev, aiMessage]);
    setIsLoading(false);
    
    // Auto-speak the AI's response if enabled
    if (autoSpeak) {
      speak(response, lang);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-80px)] max-w-4xl mx-auto bg-earth-100 rounded-t-[3rem] shadow-2xl overflow-hidden mt-2">
      <div className="bg-leaf-700 text-white p-6 flex justify-between items-center shadow-md">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-leaf-600 rounded-full transition-colors">
            <ArrowLeft size={24} />
          </button>
          <div className="bg-leaf-100 p-2 rounded-2xl">
            <Bot className="text-leaf-700" size={28} />
          </div>
          <div>
            <h2 className="text-xl font-bold serif">{t.title} AI</h2>
            <p className="text-leaf-100 text-sm opacity-80">{t.tagline}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setAutoSpeak(!autoSpeak)}
            className={`p-2 rounded-lg transition-colors flex items-center gap-2 ${autoSpeak ? 'bg-leaf-600' : 'bg-leaf-800'}`}
            title={autoSpeak ? "Disable Auto-speech" : "Enable Auto-speech"}
          >
            {autoSpeak ? <Volume2 size={20} /> : <VolumeX size={20} className="opacity-50" />}
            <span className="text-xs font-bold uppercase">{autoSpeak ? 'On' : 'Off'}</span>
          </button>
          <button onClick={() => setMessages([])} className="p-2 hover:bg-leaf-600 rounded-lg transition-colors">
            <Trash2 size={24} />
          </button>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 bg-earth-50/50">
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-center opacity-60 px-10">
            <Bot size={80} className="text-leaf-400 mb-6" />
            <p className="text-2xl serif font-medium text-earth-800 leading-relaxed">
              {t.helpText}
            </p>
            <div className="mt-6 flex gap-4">
              <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-sm text-sm font-medium text-earth-700">
                <Camera size={18} className="text-leaf-600" />
                Submit Crop Photos
              </div>
              <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-sm text-sm font-medium text-earth-700">
                <Mic size={18} className="text-leaf-600" />
                Voice Commands
              </div>
            </div>
          </div>
        )}
        
        {messages.map((msg, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div className={`flex items-start gap-3 max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
              <div className={`p-2 rounded-2xl shrink-0 ${msg.role === 'user' ? 'bg-earth-300' : 'bg-leaf-100'}`}>
                {msg.role === 'user' ? <User size={20} /> : <Bot size={20} className="text-leaf-700" />}
              </div>
              <div className={`p-1 rounded-[2rem] shadow-sm flex flex-col gap-2 overflow-hidden ${
                msg.role === 'user' 
                  ? 'bg-earth-800 text-white rounded-tr-none' 
                  : 'bg-white text-earth-900 rounded-tl-none border-l-4 border-leaf-500'
              }`}>
                {msg.image && (
                  <img src={msg.image} alt="Uploaded crop" className="w-full max-h-64 object-cover rounded-[1.8rem]" />
                )}
                {msg.content && (
                  <div className="p-4 px-5 text-lg leading-relaxed whitespace-pre-wrap">
                    {msg.content}
                    {msg.role === 'assistant' && (
                      <button 
                        onClick={() => {
                          if (isSpeaking) {
                            stopSpeaking();
                          } else {
                            speak(msg.content, lang);
                          }
                        }}
                        className="mt-3 flex items-center gap-2 text-leaf-600 hover:text-leaf-800 transition-colors p-2 bg-leaf-50 rounded-xl"
                      >
                        {isSpeaking ? (
                          <>
                            <X size={20} className="text-red-500" />
                            <span className="text-sm font-bold uppercase">Stop</span>
                          </>
                        ) : (
                          <>
                            <Volume2 size={20} />
                            <span className="text-sm font-bold uppercase">Listen</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-white p-4 rounded-full shadow-sm animate-pulse flex gap-2">
              <div className="w-2 h-2 bg-leaf-400 rounded-full animate-bounce" />
              <div className="w-2 h-2 bg-leaf-400 rounded-full animate-bounce [animation-delay:0.2s]" />
              <div className="w-2 h-2 bg-leaf-400 rounded-full animate-bounce [animation-delay:0.4s]" />
            </div>
          </div>
        )}
      </div>

      <div className="p-6 bg-white border-t border-earth-100 shadow-[0_-10px_20px_rgba(0,0,0,0.02)]">
        <AnimatePresence>
          {selectedImage && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="relative mb-4 max-w-[200px]"
            >
              <img src={selectedImage} alt="Selected" className="h-40 w-full object-cover rounded-2xl shadow-lg border-2 border-leaf-500" />
              <button 
                onClick={clearImage}
                className="absolute -top-2 -right-2 bg-red-500 text-white p-1 rounded-full shadow-md"
              >
                <X size={16} />
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="flex gap-4 items-center max-w-3xl mx-auto">
          <input 
            type="file" 
            ref={fileInputRef}
            onChange={handleImageSelect}
            accept="image/*"
            className="hidden"
          />
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="p-4 bg-earth-50 text-leaf-700 rounded-full hover:bg-leaf-50 transition-colors shadow-inner"
          >
            <Camera size={30} />
          </button>

          <div className="flex-1 relative">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend(input)}
              placeholder={t.askQuestion}
              className="w-full pl-6 pr-12 py-5 rounded-[2rem] bg-earth-50 border-2 border-earth-100 focus:border-leaf-500 focus:ring-0 outline-none text-lg"
            />
            <button 
              onClick={() => handleSend(input)}
              className="absolute right-4 top-1/2 -translate-y-1/2 p-2 text-leaf-600 hover:text-leaf-800 transition-colors"
            >
              <Send size={28} />
            </button>
          </div>
          
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => startListening(lang)}
            className={`p-5 rounded-full shadow-xl transition-colors ${
              isListening ? 'bg-red-500 text-white animate-pulse' : 'bg-leaf-600 text-white'
            }`}
          >
            <Mic size={32} />
          </motion.button>
        </div>
        {isListening && (
          <p className="text-center mt-3 text-red-500 font-medium animate-pulse">{t.voiceSearch}</p>
        )}
      </div>
    </div>
  );
};
