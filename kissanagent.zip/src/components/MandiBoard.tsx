import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Search, MapPin, TrendingUp, TrendingDown, ArrowLeft, Info } from 'lucide-react';
import { Language, translations } from '../types';

const MOCK_MANDI_DATA = [
  { id: 1, crop: 'Wheat', variety: 'Sharbati', market: 'Sehore, MP', price: 2350, change: '+50', trend: 'up' },
  { id: 2, crop: 'Rice', variety: 'Basmati', market: 'Karnal, HR', price: 4200, change: '-120', trend: 'down' },
  { id: 3, crop: 'Soybean', variety: 'Yellow', market: 'Indore, MP', price: 4800, change: '+40', trend: 'up' },
  { id: 4, crop: 'Cotton', variety: 'Kalyan', market: 'Rajkot, GJ', price: 7100, change: '+200', trend: 'up' },
  { id: 5, crop: 'Onion', variety: 'Red', market: 'Lasalgaon, MH', price: 1850, change: '-10', trend: 'down' },
  { id: 6, crop: 'Maize', variety: 'Hybrid', market: 'Chhindwara, MP', price: 1950, change: '+15', trend: 'up' },
];

export const MandiBoard: React.FC<{ lang: Language; onBack: () => void }> = ({ lang, onBack }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const t = translations[lang];

  const filteredData = MOCK_MANDI_DATA.filter(item => 
    item.crop.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.market.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="max-w-6xl mx-auto p-4 md:p-8 space-y-8 h-full bg-earth-50 rounded-t-[3rem]">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-3 bg-white rounded-2xl shadow-sm hover:shadow-md transition-shadow">
            <ArrowLeft size={24} />
          </button>
          <div>
            <h2 className="text-3xl font-bold serif text-earth-900">{t.mandiPrices}</h2>
            <p className="text-earth-600">Updated today, 05:00 AM</p>
          </div>
        </div>

        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-earth-400" size={20} />
          <input
            type="text"
            placeholder="Search crop or market..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-4 rounded-2xl bg-white border-2 border-earth-100 focus:border-leaf-500 outline-none shadow-sm transition-all"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredData.map((item) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white p-6 rounded-[2rem] shadow-lg border border-earth-100 flex flex-col justify-between"
          >
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-2xl font-bold serif text-leaf-800">{item.crop}</h3>
                <p className="text-earth-500 text-sm font-medium uppercase tracking-wider">{item.variety}</p>
              </div>
              <div className={`flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold ${
                item.trend === 'up' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
              }`}>
                {item.trend === 'up' ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                {item.change}
              </div>
            </div>

            <div className="flex items-center gap-2 text-earth-700 mb-6">
              <MapPin size={18} className="text-leaf-600" />
              <span className="font-medium">{item.market}</span>
            </div>

            <div className="flex items-end justify-between border-t border-earth-50 pt-4">
              <div>
                <p className="text-earth-400 text-sm">{t.marketRates}</p>
                <div className="flex items-baseline gap-1">
                  <span className="text-3xl font-bold text-earth-900">₹{item.price}</span>
                  <span className="text-earth-500 font-medium">/quintal</span>
                </div>
              </div>
              <button className="p-3 bg-earth-50 rounded-2xl text-leaf-700 hover:bg-leaf-100 transition-colors">
                <Info size={20} />
              </button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};
