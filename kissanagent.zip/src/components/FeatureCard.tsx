import React from 'react';
import { motion } from 'motion/react';
import { LucideIcon } from 'lucide-react';

interface FeatureCardProps {
  title: string;
  icon: LucideIcon;
  onClick: () => void;
  colorClass: string;
}

export const FeatureCard: React.FC<FeatureCardProps> = ({ title, icon: Icon, onClick, colorClass }) => {
  return (
    <motion.button
      whileHover={{ y: -5, scale: 1.02 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className={`relative overflow-hidden bg-white rounded-[2.5rem] p-8 shadow-xl flex flex-col items-center justify-center gap-6 border-b-8 ${colorClass} text-center min-h-[220px] w-full transition-shadow hover:shadow-2xl`}
    >
      <div className={`p-5 rounded-3xl ${colorClass.replace('border-b', 'bg').replace('-600', '-100')} ${colorClass.replace('border-b', 'text').replace('-600', '-700')}`}>
        <Icon size={48} strokeWidth={1.5} />
      </div>
      <span className="text-xl font-bold serif text-earth-900 tracking-tight leading-tight">
        {title}
      </span>
    </motion.button>
  );
};
