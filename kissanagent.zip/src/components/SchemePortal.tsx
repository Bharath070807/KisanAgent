import React from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, Calendar, IndianRupee, ArrowRight, ArrowLeft } from 'lucide-react';
import { Language, translations } from '../types';

const SCHEMES = [
  {
    id: 1,
    title: 'PM-KISAN',
    fullname: 'Pradhan Mantri Kisan Samman Nidhi',
    benefit: '₹6,000 per year',
    eligibility: 'All landholding farmer families',
    icon: <IndianRupee size={32} />
  },
  {
    id: 2,
    title: 'PM-FBY',
    fullname: 'Pradhan Mantri Fasal Bima Yojana',
    benefit: 'Crop insurance for all stages',
    eligibility: 'All farmers including sharecroppers',
    icon: <ShieldCheck size={32} />
  },
  {
    id: 3,
    title: 'PM-KMY',
    fullname: 'Pradhan Mantri Kisan Maandhan Yojana',
    benefit: '₹3,000 monthly pension',
    eligibility: 'Farmers between 18-40 years',
    icon: <Calendar size={32} />
  },
];

export const SchemePortal: React.FC<{ lang: Language; onBack: () => void }> = ({ lang, onBack }) => {
  const t = translations[lang];

  return (
    <div className="max-w-6xl mx-auto p-4 md:p-8 space-y-8 h-full bg-earth-50 rounded-t-[3rem]">
      <div className="flex items-center gap-4">
        <button onClick={onBack} className="p-3 bg-white rounded-2xl shadow-sm hover:shadow-md transition-shadow">
          <ArrowLeft size={24} />
        </button>
        <div>
          <h2 className="text-3xl font-bold serif text-earth-900">{t.schemes}</h2>
          <p className="text-earth-600">Updated Schemes from Ministry of Agriculture</p>
        </div>
      </div>

      <div className="space-y-6">
        {SCHEMES.map((scheme, idx) => (
          <motion.div
            key={scheme.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="group relative bg-white p-6 md:p-8 rounded-[2.5rem] shadow-lg hover:shadow-xl transition-all border-l-8 border-leaf-600 flex flex-col md:flex-row gap-8 items-start md:items-center"
          >
            <div className="p-6 bg-leaf-50 text-leaf-700 rounded-3xl group-hover:bg-leaf-600 group-hover:text-white transition-colors">
              {scheme.icon}
            </div>
            
            <div className="flex-1 space-y-2">
              <div className="flex items-baseline gap-3">
                <h3 className="text-2xl font-bold serif text-earth-900">{scheme.title}</h3>
                <span className="text-leaf-600 font-semibold text-sm uppercase tracking-wider">Active</span>
              </div>
              <p className="text-lg font-medium text-earth-700 leading-tight">{scheme.fullname}</p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                <div className="bg-earth-50 p-4 rounded-2xl">
                  <p className="text-xs uppercase font-bold text-earth-400 mb-1">Benefits</p>
                  <p className="text-earth-900 font-bold">{scheme.benefit}</p>
                </div>
                <div className="bg-earth-50 p-4 rounded-2xl">
                  <p className="text-xs uppercase font-bold text-earth-400 mb-1">Who can apply</p>
                  <p className="text-earth-900 font-bold">{scheme.eligibility}</p>
                </div>
              </div>
            </div>

            <button className="w-full md:w-auto px-8 py-4 bg-leaf-700 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-leaf-800 transition-colors self-end md:self-center">
              Apply Now
              <ArrowRight size={20} />
            </button>
          </motion.div>
        ))}
      </div>
    </div>
  );
};
