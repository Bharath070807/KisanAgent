export type Language = 'en' | 'hi' | 'te' | 'pa' | 'mr' | 'kn';

export interface Translation {
  title: string;
  tagline: string;
  subtitle: string;
  helpText: string;
  voiceAction: string;
  mandiPrices: string;
  schemes: string;
  aiExpert: string;
  languageSelect: string;
  cropAdvice: string;
  weatherInfo: string;
  marketRates: string;
  schemesList: string;
  voiceSearch: string;
  askQuestion: string;
  back: string;
}

export const translations: Record<Language, Translation> = {
  en: {
    title: "KissanAgent",
    tagline: "Your Smart Farming Companion",
    subtitle: "AI-powered expertise for every farmer",
    helpText: "How can KissanAgent help you today?",
    voiceAction: "Tap to Speak",
    mandiPrices: "Mandi Prices",
    schemes: "Govt Schemes",
    aiExpert: "AI Farming Expert",
    languageSelect: "Language",
    cropAdvice: "Crop Advice",
    weatherInfo: "Weather",
    marketRates: "Market Rates",
    schemesList: "Welfare Schemes",
    voiceSearch: "Listening...",
    askQuestion: "Ask about pests, weather or seeds",
    back: "Back"
  },
  hi: {
    title: "किसान एजेंट",
    tagline: "आपका स्मार्ट खेती साथी",
    subtitle: "हर किसान के लिए एआई विशेषज्ञता",
    helpText: "किसान एजेंट आज आपकी कैसे मदद कर सकता है?",
    voiceAction: "बोलने के लिए टैप करें",
    mandiPrices: "मंडी भाव",
    schemes: "सरकारी योजनाएं",
    aiExpert: "एआई खेती विशेषज्ञ",
    languageSelect: "भाषा",
    cropAdvice: "फसल सलाह",
    weatherInfo: "मौसम",
    marketRates: "बाज़ार दर",
    schemesList: "कल्याणकारी योजनाएं",
    voiceSearch: "सुन रहे हैं...",
    askQuestion: "कीड़ों, मौसम या बीजों के बारे में पूछें",
    back: "पीछे"
  },
  te: {
    title: "కిసాన్ ఏజెంట్",
    tagline: "మీ స్మార్ట్ ఫార్మింగ్ కంపానియన్",
    subtitle: "ప్రతి రైతుకు ఏఐ నైపుణ్యం",
    helpText: "కిసాన్ ఏజెంట్ మీకు ఈరోజు ఎలా సహాయం చేయగలరు?",
    voiceAction: "మాట్లాడటానికి నొక్కండి",
    mandiPrices: "మండీ ధరలు",
    schemes: "ప్రభుత్వ పథకాలు",
    aiExpert: "ఏఐ వ్యవసాయ నిపుణుడు",
    languageSelect: "భాష",
    cropAdvice: "పంట సలహా",
    weatherInfo: "వాతావరణం",
    marketRates: "మార్కెట్ ధరలు",
    schemesList: "సంక్షేమ పథకాలు",
    voiceSearch: "వింటున్నారు...",
    askQuestion: "పురుగులు, వాతావరణం లేదా విత్తనాల గురించి అడగండి",
    back: "వెనుకకు"
  },
  pa: {
    title: "ਕਿਸਾਨ ਏਜੰਟ",
    tagline: "ਤੁਹਾਡਾ ਸਮਾਰਟ ਖੇਤੀ ਸਾਥੀ",
    subtitle: "ਹਰ ਕਿਸਾਨ ਲਈ AI ਮੁਹਾਰਤ",
    helpText: "ਕਿਸਾਨ ਏਜੰਟ ਅੱਜ ਤੁਹਾਡੀ ਕਿਵੇਂ ਮਦਦ ਕਰ ਸਕਦਾ ਹੈ?",
    voiceAction: "ਬੋਲਣ ਲਈ ਟੈਪ ਕਰੋ",
    mandiPrices: "ਮੰਡੀ ਦੇ ਭਾਅ",
    schemes: "ਸਰਕਾਰੀ ਸਕੀਮਾਂ",
    aiExpert: "AI ਖੇਤੀ ਮਾਹਿਰ",
    languageSelect: "ਭਾਸ਼ਾ",
    cropAdvice: "ਫਸਲ ਦੀ ਸਲਾਹ",
    weatherInfo: "ਮੌਸਮ",
    marketRates: "ਮਾਰਕੀਟ ਦਰਾਂ",
    schemesList: "ਭਲਾਈ ਸਕੀਮਾਂ",
    voiceSearch: "ਸੁਣ ਰਿਹਾ ਹੈ...",
    askQuestion: "ਕੀੜਿਆਂ, ਮੌਸਮ ਜਾਂ ਬੀਜਾਂ ਬਾਰੇ ਪੁੱਛੋ",
    back: "ਪਿੱਛੇ"
  },
  mr: {
    title: "किसान एजंट",
    tagline: "तुमचा स्मार्ट शेती सोबती",
    subtitle: "प्रत्येक शेतकऱ्यासाठी AI कौशल्य",
    helpText: "किसान एजंट आज तुम्हाला कशी मदत करू शकतात?",
    voiceAction: "बोलण्यासाठी दाबा",
    mandiPrices: "मंडी भाव",
    schemes: "शासकीय योजना",
    aiExpert: "AI शेती तज्ज्ञ",
    languageSelect: "भाषा",
    cropAdvice: "पीक सल्ला",
    weatherInfo: "हवामान",
    marketRates: "बाजार दर",
    schemesList: "कल्याणकारी योजना",
    voiceSearch: "ऐकत आहे...",
    askQuestion: "कीड, हवामान किंवा बियाण्यांबद्दल विचारा",
    back: "मागे"
  },
  kn: {
    title: "ಕಿಸಾನ್ ಏಜೆಂಟ್",
    tagline: "ನಿಮ್ಮ ಸ್ಮಾರ್ಟ್ ಫಾರ್ಮಿಂಗ್ ಕಂಪ್ಯಾನಿಯನ್",
    subtitle: "ಪ್ರತಿ ರೈತರಿಗೆ AI ಪರಿಣತಿ",
    helpText: "ಕಿಸಾನ್ ಏಜೆಂಟ್ ಇಂದು ನಿಮಗೆ ಹೇಗೆ ಸಹಾಯ ಮಾಡಬಹುದು?",
    voiceAction: "ಮಾತನಾಡಲು ಒತ್ತಿರಿ",
    mandiPrices: "ಮಂಡಿ ದರ",
    schemes: "ಸರ್ಕಾರಿ ಯೋಜನೆಗಳು",
    aiExpert: "AI ಕೃಷಿ ತಜ್ಞ",
    languageSelect: "ಭಾಷೆ",
    cropAdvice: "ಬೆಳೆ ಸಲಹೆ",
    weatherInfo: "ಹವಾಮಾನ",
    marketRates: "ಮಾರುಕಟ್ಟೆ ದರ",
    schemesList: "ಕಲ್ಯಾಣ ಯೋಜನೆಗಳು",
    voiceSearch: "ಕೇಳುತ್ತಿದೆ...",
    askQuestion: "ಕೀಟಗಳು, ಹವಾಮಾನ ಅಥವಾ ಬೀಜಗಳ ಬಗ್ಗೆ ಕೇಳಿ",
    back: "ಹಿಂದಕ್ಕೆ"
  }
};

