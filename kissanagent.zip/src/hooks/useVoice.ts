import { useState, useCallback } from 'react';
import { Language } from '../types';

const LANG_MAP: Record<Language, string> = {
  en: 'en-IN',
  hi: 'hi-IN',
  te: 'te-IN',
  pa: 'pa-IN',
  mr: 'mr-IN',
  kn: 'kn-IN'
};

export function useVoiceRecognition() {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [error, setError] = useState<string | null>(null);

  const startListening = useCallback((lang: Language = 'hi') => {
    // @ts-ignore
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setError("Speech Recognition is not supported in this browser.");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = LANG_MAP[lang] || 'hi-IN';

    recognition.onstart = () => {
      setIsListening(true);
      setError(null);
    };
    recognition.onend = () => setIsListening(false);
    recognition.onresult = (event: any) => {
      const current = event.resultIndex;
      const result = event.results[current][0].transcript;
      setTranscript(result);
    };
    recognition.onerror = (event: any) => {
      console.error("Speech Recognition Error:", event.error);
      setError(event.error);
      setIsListening(false);
    };

    recognition.start();
  }, []);

  const stopSpeaking = useCallback(() => {
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
  }, []);

  const speak = useCallback((text: string, lang: Language = 'hi') => {
    // Stop any current speaking
    window.speechSynthesis.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = LANG_MAP[lang] || 'hi-IN';
    
    // Choose a better voice if available
    const voices = window.speechSynthesis.getVoices();
    const targetedVoice = voices.find(v => v.lang.startsWith(utterance.lang));
    if (targetedVoice) {
      utterance.voice = targetedVoice;
    }
    
    utterance.rate = 0.9; // Slightly slower for clarity

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  }, []);

  return { isListening, isSpeaking, transcript, error, startListening, speak, stopSpeaking };
}
